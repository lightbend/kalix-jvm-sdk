package customer.domain;

public record Address(String street, String city) {
}
